import React from 'react';
import { View, StyleSheet } from 'react-native';
import * as Font from 'expo-font';
import Header from './component/Header';
import MenuCard from './component/MenuCard';

export default function App() {
//-------------------------------------------------------------
    Font.loadAsync({
      'Kanit-Bold': require('./assets/fonts/Kanit-Bold.ttf'),
    });
//-------------------------------------------------------------  
    return (
    <View style={styles.container}>
      <Header /> 
      <MenuCard title="ข้าวผัด" price="50" description="ข้าวผัดหมู " isRecommended={true} />
      <MenuCard title="ข้าวผัด" price="50" description="ข้าวผัดไก่ " isRecommended={true} />
      <MenuCard title="ข้าวผัด" price="40" description="ข้าวผัดใส่ไข่" isRecommended={false} />
      <MenuCard title="เส้น" price="40" description="ผัดซีอิ๊ว" isRecommended={false} />
      <MenuCard title="หมูกรอบ" price="50" description="ข้าวคะน้าหมูกรอบ" isRecommended={false} />
      
    </View>
  );
}
//-------------------------------------------------------------
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff'
  },
});