//แนะนำ
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function Badge({ text }) {
  return (
    <View style={styles.badge}>
      <Text style={styles.badgeText}>{text}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    backgroundColor: 'green',
    borderRadius: 5,
    paddingHorizontal: 10,
    paddingVertical: 5,
    alignSelf: 'flex-start',
    marginTop: 2,
  },
  badgeText: {
    color: '#fff',
    fontFamily: 'Kanit-Bold',
    fontSize: 12,
  },
});