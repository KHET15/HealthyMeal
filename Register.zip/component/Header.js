//แทบฟ้า
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function Header() {
  return (
    <View style={styles.header}>
      <Text style={styles.title}>เมนูอาหาร</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    backgroundColor: '#2196F3',
    padding: 15,
  },
  title: {
    fontSize: 20,
    fontFamily: 'Kanit-Bold',
    color: '#fff',
    textAlign: 'center',
  },
});