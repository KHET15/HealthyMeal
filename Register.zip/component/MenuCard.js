//ตัวเลืกเมนู
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Badge from './Badge';

export default function MenuCard({ title, price, description, isRecommended }) {
  return (
    <View style={styles.card}>
      <Text style={styles.menuTitle}>{title}</Text>
      <Text style={styles.price}>฿{price}</Text>
      <Text style={styles.description}>{description}</Text>
      {isRecommended && <Badge text="แนะนำ" />}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    padding: 5,
    margin: 5,
    borderWidth: 2,
    borderColor: '#ccc',
    borderRadius: 5,
  },
  menuTitle: { //เมนู
    fontSize: 20,
    fontFamily: 'Kanit-Bold',
  },
  price: { //ราคา
    fontSize: 16,
    fontFamily: 'Kanit-Bold',
    color: 'green',
  },
  description: { //เมนู
    fontSize: 16,
    fontFamily: 'Kanit-Bold',
    color: '#777',
  },
});